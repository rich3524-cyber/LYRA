# LYRA — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build LYRA — a premium AI-powered social media intelligence SaaS platform that schedules content, generates brand-specific AI captions, and uniquely responds to comments and reviews autonomously across all major social platforms.

**Architecture:** Multi-tenant Next.js SaaS with per-client workspace isolation, a Brand Intelligence Engine powered by the Anthropic Claude API, real-time social platform API integrations via webhooks and polling, and a configurable AI response autonomy layer with agency-level guardrails.

**Tech Stack:** Next.js 15 (App Router), TypeScript, Tailwind CSS, shadcn/ui, Prisma ORM, PostgreSQL, Redis + BullMQ, Anthropic Claude API, Auth0, Stripe, AWS S3, Vercel deployment.

---

## Design System & UI/UX Standards

Before any UI work begins, all developers must internalize these non-negotiable standards. LYRA is a **premium, ultra-minimal, near-black/platinum** product. Every screen must feel like it was designed by a senior product designer at a tier-1 tech company.

### Visual Identity Tokens

```typescript
// lib/design-tokens.ts
export const tokens = {
  colors: {
    background: {
      primary:   '#080808',   // Near-black — main app background
      secondary: '#0f0f0f',   // Card backgrounds
      tertiary:  '#141414',   // Elevated surfaces
      hover:     '#1a1a1a',   // Hover states
      border:    '#222222',   // Subtle borders
      borderMid: '#333333',   // Mid borders
    },
    text: {
      primary:   '#e2e2e2',   // Platinum — primary text
      secondary: '#888888',   // Secondary text
      tertiary:  '#555555',   // Muted / disabled text
      inverse:   '#080808',   // Text on light backgrounds
    },
    accent: {
      platinum:  '#d8d8d8',   // Primary accent
      white:     '#f4f4f2',   // Pure white moments
      silver:    '#aaaaaa',   // Mid silver
    },
    status: {
      success:   '#4ade80',   // Green — keep desaturated
      warning:   '#fbbf24',   // Amber
      error:     '#f87171',   // Red
      info:      '#60a5fa',   // Blue
    }
  },
  typography: {
    // Primary wordmark / headings
    display: '"Instrument Serif", "Playfair Display", Georgia, serif',
    // UI / body — NOT Inter or Arial
    sans: '"DM Sans", "Geist", system-ui, sans-serif',
    // Monospace for data/code
    mono: '"Geist Mono", "JetBrains Mono", monospace',
  },
  spacing: {
    // 4px base unit
    1: '4px', 2: '8px', 3: '12px', 4: '16px',
    5: '20px', 6: '24px', 8: '32px', 10: '40px',
    12: '48px', 16: '64px',
  },
  radius: {
    sm: '6px', md: '10px', lg: '14px', xl: '20px', full: '9999px',
  },
  animation: {
    fast: '150ms',
    normal: '200ms',
    slow: '300ms',
    easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
  }
}
```

### Typography System

```bash
# Install fonts via Next.js font optimization
# In app/layout.tsx — use next/font/google:
# - DM_Sans: weights 300, 400, 500 — body/UI
# - Instrument_Serif: weights 400 — display/headings
# - Geist_Mono: weight 400 — code/data
```

### UI Component Library Stack

```bash
# Core UI — shadcn/ui (Radix primitives + Tailwind)
npx shadcn@latest init

# Install all required shadcn components upfront:
npx shadcn@latest add button card dialog dropdown-menu
npx shadcn@latest add form input label select textarea
npx shadcn@latest add table tabs badge avatar separator
npx shadcn@latest add popover command tooltip sheet
npx shadcn@latest add calendar date-picker progress
npx shadcn@latest add alert-dialog scroll-area skeleton
npx shadcn@latest add navigation-menu breadcrumb switch
npx shadcn@latest add checkbox radio-group slider toggle

# Animation
npm install framer-motion

# Icons — Lucide ONLY (no emoji as icons, no mixing icon sets)
npm install lucide-react

# Charts
npm install recharts

# Date handling
npm install date-fns

# Rich text editor (for post composition)
npm install @tiptap/react @tiptap/starter-kit @tiptap/extension-placeholder

# Drag and drop (content calendar)
npm install @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities

# File upload
npm install react-dropzone

# Image handling
npm install sharp

# Toast notifications
npm install sonner
```

### UX Non-Negotiables

Every screen built for LYRA must pass this checklist before merge:

**Visual Quality**
- [ ] No emoji used as icons — Lucide icons only
- [ ] All surfaces use design tokens — no hardcoded hex values in components
- [ ] Near-black background on all authenticated pages
- [ ] Platinum/silver text hierarchy (primary #e2e2e2, secondary #888, muted #555)
- [ ] Border radius consistent — use token values only
- [ ] Subtle borders (#222) on all cards/panels — no floating elements without boundary

**Typography**
- [ ] DM Sans for all UI text (labels, buttons, body)
- [ ] Instrument Serif for display headings only (page titles, marketing)
- [ ] Geist Mono for all data values (counts, IDs, code)
- [ ] No font sizes below 12px
- [ ] Line-height 1.5 for body text minimum

**Interaction**
- [ ] All clickable elements have cursor-pointer
- [ ] Loading states on all async operations (skeleton loaders, not spinners where possible)
- [ ] Button disabled + spinner during async submission
- [ ] Hover states on all interactive elements (150ms transition)
- [ ] Focus rings visible on keyboard navigation (2px platinum outline)
- [ ] Touch targets minimum 44×44px

**Animation**
- [ ] Page transitions: 200ms fade + subtle translate-y (8px → 0)
- [ ] Modal/sheet: 200ms with scale (0.96 → 1) + fade
- [ ] Sidebar collapse: 250ms with easing
- [ ] Skeleton loaders on all data-dependent content
- [ ] Respect prefers-reduced-motion

**Accessibility**
- [ ] Contrast ratio 4.5:1 minimum for all body text
- [ ] All form inputs have associated labels
- [ ] ARIA labels on all icon-only buttons
- [ ] Keyboard navigation works on all interactive elements
- [ ] Error messages appear adjacent to the field, not only at top

---

## Project Structure

```
lyra/
├── app/
│   ├── (auth)/                    # Auth routes (login, signup, onboarding)
│   │   ├── login/
│   │   ├── signup/
│   │   └── onboard/               # Guided client onboarding link flow
│   ├── (dashboard)/               # Authenticated app
│   │   ├── layout.tsx             # App shell (sidebar + header)
│   │   ├── page.tsx               # Dashboard home
│   │   ├── workspace/
│   │   │   └── [workspaceId]/
│   │   │       ├── calendar/      # Content calendar
│   │   │       ├── compose/       # Post composer
│   │   │       ├── inbox/         # Comment/review response inbox
│   │   │       ├── brand/         # Brand intelligence profile
│   │   │       ├── analytics/     # Performance dashboard
│   │   │       └── settings/      # Workspace settings
│   │   ├── agency/
│   │   │   ├── clients/           # Client workspace management
│   │   │   ├── team/              # Team member management
│   │   │   └── settings/          # Agency settings + guardrails
│   │   └── account/               # User account + billing
│   ├── api/
│   │   ├── auth/                  # Auth0 callbacks
│   │   ├── webhooks/              # Social platform webhooks
│   │   │   ├── facebook/
│   │   │   ├── instagram/
│   │   │   ├── google/
│   │   │   └── linkedin/
│   │   ├── workspaces/            # Workspace CRUD
│   │   ├── posts/                 # Post management
│   │   ├── brand-intelligence/    # Brand profile endpoints
│   │   ├── ai/
│   │   │   ├── generate/          # Caption generation
│   │   │   └── respond/           # Comment response generation
│   │   ├── social/
│   │   │   ├── connect/           # OAuth flows
│   │   │   ├── publish/           # Publishing endpoint
│   │   │   └── sync/              # Data sync jobs
│   │   ├── onboarding/            # Guided onboarding token management
│   │   ├── stripe/                # Billing webhooks
│   │   └── cron/                  # Scheduled job triggers
│   └── layout.tsx
├── components/
│   ├── ui/                        # shadcn/ui components (auto-generated)
│   ├── lyra/                      # LYRA custom components
│   │   ├── app-shell/
│   │   │   ├── sidebar.tsx
│   │   │   ├── header.tsx
│   │   │   └── workspace-switcher.tsx
│   │   ├── calendar/
│   │   │   ├── content-calendar.tsx
│   │   │   ├── calendar-day.tsx
│   │   │   └── post-preview-card.tsx
│   │   ├── composer/
│   │   │   ├── post-composer.tsx
│   │   │   ├── platform-selector.tsx
│   │   │   ├── media-uploader.tsx
│   │   │   └── ai-suggest-panel.tsx
│   │   ├── inbox/
│   │   │   ├── response-inbox.tsx
│   │   │   ├── comment-card.tsx
│   │   │   └── response-composer.tsx
│   │   ├── brand/
│   │   │   ├── brand-profile.tsx
│   │   │   ├── voice-summary.tsx
│   │   │   └── intelligence-status.tsx
│   │   ├── analytics/
│   │   │   ├── performance-dashboard.tsx
│   │   │   ├── engagement-chart.tsx
│   │   │   └── platform-breakdown.tsx
│   │   └── onboarding/
│   │       ├── onboarding-flow.tsx
│   │       └── social-connect-step.tsx
├── lib/
│   ├── design-tokens.ts
│   ├── auth.ts                    # Auth0 helpers
│   ├── prisma.ts                  # Prisma client singleton
│   ├── redis.ts                   # Redis client
│   ├── stripe.ts                  # Stripe client
│   ├── anthropic.ts               # Claude API client
│   ├── s3.ts                      # AWS S3 helpers
│   └── utils.ts
├── services/
│   ├── brand-intelligence/
│   │   ├── scraper.ts             # Website scraper
│   │   ├── social-analyzer.ts     # Social feed analyzer
│   │   ├── document-parser.ts     # Brand guidelines parser
│   │   └── profile-builder.ts     # Brand profile aggregator
│   ├── ai/
│   │   ├── caption-generator.ts   # Post caption generation
│   │   ├── response-generator.ts  # Comment response generation
│   │   └── prompt-builder.ts      # Prompt construction from brand profile
│   ├── social/
│   │   ├── facebook.ts
│   │   ├── instagram.ts
│   │   ├── linkedin.ts
│   │   ├── tiktok.ts
│   │   ├── twitter.ts
│   │   └── google-business.ts
│   └── scheduler/
│       ├── post-queue.ts          # BullMQ post scheduling
│       └── sync-queue.ts          # Background sync jobs
├── workers/
│   ├── post-publisher.worker.ts   # Processes scheduled posts
│   ├── comment-monitor.worker.ts  # Monitors for new comments
│   ├── brand-sync.worker.ts       # Refreshes brand intelligence
│   └── ai-responder.worker.ts     # Generates + posts AI responses
├── prisma/
│   └── schema.prisma
├── types/
│   └── index.ts
└── middleware.ts                  # Auth + workspace access control
```

---

## Database Schema

```prisma
// prisma/schema.prisma

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id            String    @id @default(cuid())
  auth0Id       String    @unique
  email         String    @unique
  name          String?
  avatarUrl     String?
  role          UserRole  @default(SMB_OWNER)
  agencyId      String?
  agency        Agency?   @relation(fields: [agencyId], references: [id])
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt

  workspaceAccess WorkspaceAccess[]
  posts           Post[]
  approvals       PostApproval[]
}

enum UserRole {
  PLATFORM_OWNER
  AGENCY_ADMIN
  AGENCY_MEMBER
  CLIENT_VIEW
  CLIENT_APPROVE
  SMB_OWNER
}

model Agency {
  id              String      @id @default(cuid())
  name            String
  plan            Plan        @default(AGENCY)
  stripeCustomerId String?    @unique
  stripeSubId     String?     @unique
  maxWorkspaces   Int         @default(-1) // -1 = unlimited
  maxAutonomy     Autonomy    @default(FULL) // Agency ceiling
  createdAt       DateTime    @default(now())
  updatedAt       DateTime    @updatedAt

  members         User[]
  workspaces      Workspace[]
}

model Workspace {
  id              String    @id @default(cuid())
  name            String
  industry        String?
  websiteUrl      String?
  agencyId        String?
  agency          Agency?   @relation(fields: [agencyId], references: [id])
  ownerId         String?   // For SMB direct accounts
  plan            Plan      @default(STARTER)
  stripeCustomerId String?  @unique
  clientAccessLevel ClientAccess @default(NONE)
  aiResponseMode  Autonomy  @default(OFF)
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  access          WorkspaceAccess[]
  socialAccounts  SocialAccount[]
  posts           Post[]
  brandProfile    BrandProfile?
  guardrails      Guardrail[]
  onboardingToken OnboardingToken?
}

enum Plan {
  STARTER
  PRO
  AGENCY
}

enum ClientAccess {
  NONE
  VIEW
  APPROVE
}

enum Autonomy {
  OFF
  DRAFT_APPROVE
  FULL
}

model WorkspaceAccess {
  id          String    @id @default(cuid())
  userId      String
  workspaceId String
  role        UserRole
  user        User      @relation(fields: [userId], references: [id])
  workspace   Workspace @relation(fields: [workspaceId], references: [id])
  createdAt   DateTime  @default(now())

  @@unique([userId, workspaceId])
}

model SocialAccount {
  id            String    @id @default(cuid())
  workspaceId   String
  workspace     Workspace @relation(fields: [workspaceId], references: [id])
  platform      Platform
  platformId    String    // Platform's own ID for this account
  handle        String
  name          String
  avatarUrl     String?
  accessToken   String    // Encrypted
  refreshToken  String?   // Encrypted
  tokenExpiry   DateTime?
  webhookId     String?
  isActive      Boolean   @default(true)
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt

  posts         Post[]
  comments      Comment[]

  @@unique([workspaceId, platform, platformId])
}

enum Platform {
  FACEBOOK
  INSTAGRAM
  LINKEDIN
  TIKTOK
  TWITTER
  GOOGLE_BUSINESS
  YOUTUBE
  PINTEREST
  THREADS
  BLUESKY
}

model Post {
  id              String    @id @default(cuid())
  workspaceId     String
  workspace       Workspace @relation(fields: [workspaceId], references: [id])
  socialAccountId String
  socialAccount   SocialAccount @relation(fields: [socialAccountId], references: [id])
  authorId        String
  author          User      @relation(fields: [authorId], references: [id])
  content         String
  mediaUrls       String[]
  status          PostStatus @default(DRAFT)
  scheduledAt     DateTime?
  publishedAt     DateTime?
  platformPostId  String?   // ID returned from platform after publish
  aiGenerated     Boolean   @default(false)
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  approval        PostApproval?
  metrics         PostMetrics?
  comments        Comment[]
}

enum PostStatus {
  DRAFT
  PENDING_APPROVAL
  APPROVED
  SCHEDULED
  PUBLISHING
  PUBLISHED
  FAILED
  CANCELLED
}

model PostApproval {
  id          String          @id @default(cuid())
  postId      String          @unique
  post        Post            @relation(fields: [postId], references: [id])
  reviewerId  String?
  reviewer    User?           @relation(fields: [reviewerId], references: [id])
  status      ApprovalStatus  @default(PENDING)
  notes       String?
  reviewedAt  DateTime?
  createdAt   DateTime        @default(now())
}

enum ApprovalStatus {
  PENDING
  APPROVED
  REJECTED
  CHANGES_REQUESTED
}

model Comment {
  id              String    @id @default(cuid())
  workspaceId     String
  socialAccountId String
  socialAccount   SocialAccount @relation(fields: [socialAccountId], references: [id])
  postId          String?
  post            Post?     @relation(fields: [postId], references: [id])
  platformCommentId String
  authorName      String
  authorHandle    String?
  content         String
  sentiment       Sentiment?
  requiresResponse Boolean  @default(false)
  isEscalated     Boolean   @default(false)
  escalationReason String?
  status          CommentStatus @default(PENDING)
  aiDraftResponse String?
  finalResponse   String?
  respondedAt     DateTime?
  platformCreatedAt DateTime
  createdAt       DateTime  @default(now())

  responses       CommentResponse[]
}

enum Sentiment {
  POSITIVE
  NEUTRAL
  NEGATIVE
  URGENT
}

enum CommentStatus {
  PENDING
  AI_DRAFTED
  AWAITING_APPROVAL
  APPROVED
  RESPONDED
  ESCALATED
  IGNORED
}

model CommentResponse {
  id          String    @id @default(cuid())
  commentId   String
  comment     Comment   @relation(fields: [commentId], references: [id])
  content     String
  aiGenerated Boolean   @default(true)
  publishedAt DateTime?
  createdAt   DateTime  @default(now())
}

model BrandProfile {
  id              String    @id @default(cuid())
  workspaceId     String    @unique
  workspace       Workspace @relation(fields: [workspaceId], references: [id])
  voiceSummary    String?   // AI-generated voice description
  toneAttributes  String[]  // e.g. ["professional", "warm", "witty"]
  contentThemes   String[]  // e.g. ["sustainability", "community", "innovation"]
  audienceProfile Json?     // Structured audience data
  postingPatterns Json?     // Best times, frequencies per platform
  guidelineUrls   String[]  // S3 URLs for uploaded brand docs
  websiteData     Json?     // Scraped website data
  socialData      Json?     // Aggregated social feed data
  lastScrapedAt   DateTime?
  lastSocialSyncAt DateTime?
  lastUpdatedAt   DateTime?
  vectorEmbedding Bytes?    // Stored embedding for semantic search
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
}

model Guardrail {
  id            String    @id @default(cuid())
  workspaceId   String
  workspace     Workspace @relation(fields: [workspaceId], references: [id])
  type          GuardrailType
  value         String    // The topic/word/phrase to guard
  createdAt     DateTime  @default(now())
}

enum GuardrailType {
  NEVER_DISCUSS   // Topics AI must never address
  NEVER_USE_WORD  // Words/phrases prohibited
  ALWAYS_ESCALATE // Triggers that route to human
  APPROVED_ANSWER // Pre-approved responses to specific questions
}

model PostMetrics {
  id          String    @id @default(cuid())
  postId      String    @unique
  post        Post      @relation(fields: [postId], references: [id])
  likes       Int       @default(0)
  comments    Int       @default(0)
  shares      Int       @default(0)
  reach       Int       @default(0)
  impressions Int       @default(0)
  clicks      Int       @default(0)
  saves       Int       @default(0)
  lastSyncedAt DateTime?
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}

model OnboardingToken {
  id          String    @id @default(cuid())
  workspaceId String    @unique
  workspace   Workspace @relation(fields: [workspaceId], references: [id])
  token       String    @unique @default(cuid())
  expiresAt   DateTime
  completedAt DateTime?
  createdAt   DateTime  @default(now())
}
```

---

## Phase 1 — Foundation (Months 1–4)

### Task 1: Project Initialisation & Design System

**Files:**
- Create: `package.json`, `next.config.ts`, `tailwind.config.ts`
- Create: `lib/design-tokens.ts`
- Create: `app/globals.css`
- Create: `components/ui/` (shadcn auto-generated)

- [ ] **Step 1: Initialise Next.js project**
```bash
npx create-next-app@latest lyra \
  --typescript \
  --tailwind \
  --eslint \
  --app \
  --src-dir=false \
  --import-alias="@/*"
cd lyra
```

- [ ] **Step 2: Install all dependencies**
```bash
npm install @prisma/client prisma
npm install @auth0/nextjs-auth0
npm install stripe @stripe/stripe-js
npm install @aws-sdk/client-s3 @aws-sdk/s3-request-presigner
npm install bullmq ioredis
npm install @anthropic-ai/sdk
npm install framer-motion lucide-react recharts
npm install date-fns @tiptap/react @tiptap/starter-kit @tiptap/extension-placeholder
npm install @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities
npm install react-dropzone sharp sonner
npm install axios cheerio  # For web scraping
npm install -D @types/node
```

- [ ] **Step 3: Initialise shadcn/ui**
```bash
npx shadcn@latest init
# Choose: Default style, Zinc base color, CSS variables: yes
npx shadcn@latest add button card dialog dropdown-menu form input label \
  select textarea table tabs badge avatar separator popover command \
  tooltip sheet calendar progress alert-dialog scroll-area skeleton \
  navigation-menu breadcrumb switch checkbox radio-group slider toggle \
  date-picker
```

- [ ] **Step 4: Configure Tailwind with LYRA design tokens**
```typescript
// tailwind.config.ts
import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: ['class'],
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        background: {
          primary:   '#080808',
          secondary: '#0f0f0f',
          tertiary:  '#141414',
          hover:     '#1a1a1a',
          border:    '#222222',
          'border-mid': '#333333',
        },
        text: {
          primary:   '#e2e2e2',
          secondary: '#888888',
          tertiary:  '#555555',
        },
        accent: {
          platinum:  '#d8d8d8',
          white:     '#f4f4f2',
          silver:    '#aaaaaa',
        },
        status: {
          success: '#4ade80',
          warning: '#fbbf24',
          error:   '#f87171',
          info:    '#60a5fa',
        }
      },
      fontFamily: {
        display: ['"Instrument Serif"', '"Playfair Display"', 'Georgia', 'serif'],
        sans:    ['"DM Sans"', '"Geist"', 'system-ui', 'sans-serif'],
        mono:    ['"Geist Mono"', '"JetBrains Mono"', 'monospace'],
      },
      animation: {
        'fade-in':    'fadeIn 200ms cubic-bezier(0.16, 1, 0.3, 1)',
        'slide-up':   'slideUp 200ms cubic-bezier(0.16, 1, 0.3, 1)',
        'scale-in':   'scaleIn 200ms cubic-bezier(0.16, 1, 0.3, 1)',
        'shimmer':    'shimmer 2s infinite',
      },
      keyframes: {
        fadeIn:  { from: { opacity: '0' }, to: { opacity: '1' } },
        slideUp: { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        scaleIn: { from: { opacity: '0', transform: 'scale(0.96)' }, to: { opacity: '1', transform: 'scale(1)' } },
        shimmer: { '0%': { backgroundPosition: '-200% 0' }, '100%': { backgroundPosition: '200% 0' } },
      }
    },
  },
  plugins: [require('tailwindcss-animate')],
}
export default config
```

- [ ] **Step 5: Set global CSS with LYRA dark theme**
```css
/* app/globals.css */
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500&family=Instrument+Serif&display=swap');

@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 3%;
    --foreground: 0 0% 89%;
    --card: 0 0% 6%;
    --border: 0 0% 13%;
    --input: 0 0% 9%;
    --ring: 0 0% 85%;
    --radius: 0.625rem;
  }

  * { @apply border-border; }
  
  body {
    @apply bg-background-primary text-text-primary font-sans;
    font-size: 14px;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  ::selection {
    background: rgba(216, 216, 216, 0.15);
    color: #f4f4f2;
  }

  :focus-visible {
    outline: 2px solid #888;
    outline-offset: 2px;
    border-radius: 4px;
  }

  /* Scrollbar styling */
  ::-webkit-scrollbar { width: 4px; height: 4px; }
  ::-webkit-scrollbar-track { background: #080808; }
  ::-webkit-scrollbar-thumb { background: #333; border-radius: 2px; }
  ::-webkit-scrollbar-thumb:hover { background: #444; }
}
```

- [ ] **Step 6: Set up environment variables**
```bash
# .env.local
DATABASE_URL="postgresql://..."
AUTH0_SECRET="..."
AUTH0_BASE_URL="http://localhost:3000"
AUTH0_ISSUER_BASE_URL="https://your-tenant.auth0.com"
AUTH0_CLIENT_ID="..."
AUTH0_CLIENT_SECRET="..."
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_..."
ANTHROPIC_API_KEY="sk-ant-..."
AWS_REGION="ap-southeast-2"
AWS_ACCESS_KEY_ID="..."
AWS_SECRET_ACCESS_KEY="..."
S3_BUCKET_NAME="lyra-assets"
REDIS_URL="redis://localhost:6379"
FACEBOOK_APP_ID="..."
FACEBOOK_APP_SECRET="..."
GOOGLE_CLIENT_ID="..."
GOOGLE_CLIENT_SECRET="..."
LINKEDIN_CLIENT_ID="..."
LINKEDIN_CLIENT_SECRET="..."
ENCRYPTION_KEY="..."  # 32-byte key for token encryption
```

- [ ] **Step 7: Commit**
```bash
git init && git add -A
git commit -m "feat: initialise LYRA project with design system and dependencies"
```

---

### Task 2: Database Setup & Auth

**Files:**
- Create: `prisma/schema.prisma`
- Create: `lib/prisma.ts`
- Create: `lib/auth.ts`
- Create: `middleware.ts`
- Create: `app/api/auth/[auth0]/route.ts`

- [ ] **Step 1: Write Prisma schema** (use full schema from Database Schema section above)

- [ ] **Step 2: Initialise database**
```bash
npx prisma generate
npx prisma db push
```

- [ ] **Step 3: Create Prisma singleton**
```typescript
// lib/prisma.ts
import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient }

export const prisma = globalForPrisma.prisma || new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error'] : ['error'],
})

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma
```

- [ ] **Step 4: Set up Auth0**
```typescript
// app/api/auth/[auth0]/route.ts
import { handleAuth } from '@auth0/nextjs-auth0'
export const GET = handleAuth()
```

```typescript
// lib/auth.ts
import { getSession } from '@auth0/nextjs-auth0'
import { prisma } from './prisma'

export async function getCurrentUser() {
  const session = await getSession()
  if (!session?.user) return null

  return prisma.user.findUnique({
    where: { auth0Id: session.user.sub },
    include: {
      agency: true,
      workspaceAccess: { include: { workspace: true } }
    }
  })
}

export async function requireAuth() {
  const user = await getCurrentUser()
  if (!user) throw new Error('Unauthorized')
  return user
}
```

- [ ] **Step 5: Create auth middleware**
```typescript
// middleware.ts
import { withMiddlewareAuthRequired } from '@auth0/nextjs-auth0/edge'

export default withMiddlewareAuthRequired()

export const config = {
  matcher: [
    '/(dashboard)/:path*',
    '/(workspace)/:path*',
    '/agency/:path*',
    '/account/:path*',
    '/api/workspaces/:path*',
    '/api/posts/:path*',
    '/api/brand-intelligence/:path*',
    '/api/ai/:path*',
  ]
}
```

- [ ] **Step 6: Commit**
```bash
git add -A
git commit -m "feat: database schema, prisma setup, auth0 integration"
```

---

### Task 3: App Shell — Sidebar, Header, Workspace Switcher

**Files:**
- Create: `app/(dashboard)/layout.tsx`
- Create: `components/lyra/app-shell/sidebar.tsx`
- Create: `components/lyra/app-shell/header.tsx`
- Create: `components/lyra/app-shell/workspace-switcher.tsx`

- [ ] **Step 1: Build the sidebar**
```tsx
// components/lyra/app-shell/sidebar.tsx
'use client'
import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutGrid, Calendar, PenSquare, MessageSquare,
  Zap, BarChart3, Settings, Users, ChevronLeft, ChevronRight
} from 'lucide-react'
import { WorkspaceSwitcher } from './workspace-switcher'
import { cn } from '@/lib/utils'

const navItems = [
  { href: '', label: 'Dashboard',   icon: LayoutGrid },
  { href: '/calendar',   label: 'Calendar',    icon: Calendar },
  { href: '/compose',    label: 'Compose',     icon: PenSquare },
  { href: '/inbox',      label: 'Inbox',       icon: MessageSquare },
  { href: '/brand',      label: 'Brand AI',    icon: Zap },
  { href: '/analytics',  label: 'Analytics',   icon: BarChart3 },
]

export function Sidebar({ workspaceId }: { workspaceId: string }) {
  const [collapsed, setCollapsed] = useState(false)
  const pathname = usePathname()
  const base = `/workspace/${workspaceId}`

  return (
    <motion.aside
      animate={{ width: collapsed ? 64 : 240 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      className="relative flex flex-col h-screen bg-background-secondary border-r border-background-border shrink-0 overflow-hidden"
    >
      {/* Logo */}
      <div className="flex items-center h-16 px-4 border-b border-background-border shrink-0">
        <AnimatePresence mode="wait">
          {!collapsed ? (
            <motion.div
              key="full"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="font-display text-xl tracking-[0.25em] text-accent-platinum font-light"
            >
              LYRA
            </motion.div>
          ) : (
            <motion.div
              key="icon"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="w-8 h-8 border border-text-secondary flex items-center justify-center"
            >
              <span className="font-display text-sm text-accent-platinum font-light">L</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Workspace Switcher */}
      {!collapsed && (
        <div className="px-3 py-3 border-b border-background-border">
          <WorkspaceSwitcher workspaceId={workspaceId} />
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-0.5 overflow-y-auto">
        {navItems.map(({ href, label, icon: Icon }) => {
          const fullHref = `${base}${href}`
          const isActive = pathname === fullHref || (href && pathname.startsWith(fullHref))
          return (
            <Link
              key={label}
              href={fullHref}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-150 group',
                isActive
                  ? 'bg-background-hover text-text-primary'
                  : 'text-text-secondary hover:text-text-primary hover:bg-background-hover'
              )}
              aria-label={collapsed ? label : undefined}
            >
              <Icon size={16} className="shrink-0" strokeWidth={isActive ? 2 : 1.5} />
              <AnimatePresence>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: 'auto' }}
                    exit={{ opacity: 0, width: 0 }}
                    className="overflow-hidden whitespace-nowrap tracking-wide"
                  >
                    {label}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          )
        })}
      </nav>

      {/* Bottom nav */}
      <div className="border-t border-background-border p-2 space-y-0.5">
        <Link
          href="/agency/settings"
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-text-secondary hover:text-text-primary hover:bg-background-hover transition-all duration-150"
          aria-label={collapsed ? 'Settings' : undefined}
        >
          <Settings size={16} strokeWidth={1.5} className="shrink-0" />
          {!collapsed && <span className="tracking-wide">Settings</span>}
        </Link>
      </div>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 rounded-full bg-background-tertiary border border-background-border flex items-center justify-center text-text-tertiary hover:text-text-primary transition-colors z-10"
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
    </motion.aside>
  )
}
```

- [ ] **Step 2: Build the header**
```tsx
// components/lyra/app-shell/header.tsx
'use client'
import { Bell, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'

interface HeaderProps {
  user: { name?: string | null; email: string; avatarUrl?: string | null }
  title: string
}

export function Header({ user, title }: HeaderProps) {
  return (
    <header className="h-16 flex items-center justify-between px-6 border-b border-background-border bg-background-secondary shrink-0">
      <h1 className="text-sm font-medium text-text-secondary tracking-widest uppercase">
        {title}
      </h1>
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="text-text-tertiary hover:text-text-primary" aria-label="Search">
          <Search size={16} />
        </Button>
        <Button variant="ghost" size="icon" className="text-text-tertiary hover:text-text-primary" aria-label="Notifications">
          <Bell size={16} />
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-silver rounded-full" aria-label="User menu">
              <Avatar className="h-7 w-7">
                <AvatarImage src={user.avatarUrl ?? undefined} />
                <AvatarFallback className="bg-background-tertiary text-text-secondary text-xs">
                  {user.name?.[0] ?? user.email[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48 bg-background-tertiary border-background-border">
            <div className="px-2 py-1.5">
              <p className="text-xs text-text-secondary">{user.name}</p>
              <p className="text-xs text-text-tertiary truncate">{user.email}</p>
            </div>
            <DropdownMenuSeparator className="bg-background-border" />
            <DropdownMenuItem asChild>
              <a href="/account" className="text-text-secondary cursor-pointer">Account</a>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-background-border" />
            <DropdownMenuItem asChild>
              <a href="/api/auth/logout" className="text-status-error cursor-pointer">Sign out</a>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
```

- [ ] **Step 3: Build workspace switcher**
```tsx
// components/lyra/app-shell/workspace-switcher.tsx
'use client'
import { useState, useEffect } from 'react'
import { Check, ChevronsUpDown, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from '@/components/ui/command'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { cn } from '@/lib/utils'
import { useRouter } from 'next/navigation'

interface Workspace { id: string; name: string }

export function WorkspaceSwitcher({ workspaceId }: { workspaceId: string }) {
  const [open, setOpen] = useState(false)
  const [workspaces, setWorkspaces] = useState<Workspace[]>([])
  const [current, setCurrent] = useState<Workspace | null>(null)
  const router = useRouter()

  useEffect(() => {
    fetch('/api/workspaces')
      .then(r => r.json())
      .then(data => {
        setWorkspaces(data)
        setCurrent(data.find((w: Workspace) => w.id === workspaceId) ?? null)
      })
  }, [workspaceId])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          role="combobox"
          aria-expanded={open}
          aria-label="Switch workspace"
          className="w-full justify-between text-text-secondary hover:text-text-primary text-xs h-8 px-2"
        >
          <span className="truncate">{current?.name ?? 'Select workspace'}</span>
          <ChevronsUpDown size={12} className="shrink-0 ml-1 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-0 bg-background-tertiary border-background-border">
        <Command className="bg-transparent">
          <CommandInput placeholder="Search workspaces..." className="text-xs text-text-secondary" />
          <CommandEmpty className="text-xs text-text-tertiary py-3 text-center">No workspaces found.</CommandEmpty>
          <CommandGroup>
            {workspaces.map(w => (
              <CommandItem
                key={w.id}
                value={w.name}
                onSelect={() => {
                  setOpen(false)
                  router.push(`/workspace/${w.id}`)
                }}
                className="text-xs text-text-secondary cursor-pointer"
              >
                <Check size={12} className={cn('mr-2', w.id === workspaceId ? 'opacity-100' : 'opacity-0')} />
                {w.name}
              </CommandItem>
            ))}
          </CommandGroup>
          <div className="border-t border-background-border p-1">
            <Button
              variant="ghost"
              size="sm"
              className="w-full justify-start text-xs text-text-tertiary hover:text-text-primary gap-2"
              onClick={() => router.push('/agency/clients/new')}
            >
              <Plus size={12} /> New workspace
            </Button>
          </div>
        </Command>
      </PopoverContent>
    </Popover>
  )
}
```

- [ ] **Step 4: Build dashboard layout**
```tsx
// app/(dashboard)/layout.tsx
import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth'
import { Sidebar } from '@/components/lyra/app-shell/sidebar'
import { Header } from '@/components/lyra/app-shell/header'

export default async function DashboardLayout({
  children,
  params
}: {
  children: React.ReactNode
  params: { workspaceId?: string }
}) {
  const user = await getCurrentUser()
  if (!user) redirect('/api/auth/login')

  const workspaceId = params.workspaceId
    ?? user.workspaceAccess[0]?.workspaceId
    ?? ''

  return (
    <div className="flex h-screen overflow-hidden bg-background-primary">
      <Sidebar workspaceId={workspaceId} />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header user={user} title="" />
        <main className="flex-1 overflow-y-auto p-6 animate-fade-in">
          {children}
        </main>
      </div>
    </div>
  )
}
```

- [ ] **Step 5: Commit**
```bash
git add -A
git commit -m "feat: app shell — sidebar, header, workspace switcher"
```

---

### Task 4: Workspace API & Management

**Files:**
- Create: `app/api/workspaces/route.ts`
- Create: `app/api/workspaces/[id]/route.ts`
- Create: `app/(dashboard)/agency/clients/page.tsx`
- Create: `app/(dashboard)/agency/clients/new/page.tsx`

- [ ] **Step 1: Write workspace list + create API**
```typescript
// app/api/workspaces/route.ts
import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const user = await requireAuth()
  const workspaces = await prisma.workspace.findMany({
    where: {
      access: { some: { userId: user.id } }
    },
    select: { id: true, name: true, industry: true, clientAccessLevel: true }
  })
  return NextResponse.json(workspaces)
}

export async function POST(req: Request) {
  const user = await requireAuth()
  const body = await req.json()
  const { name, industry, websiteUrl, clientAccessLevel } = body

  if (!name) return NextResponse.json({ error: 'Name required' }, { status: 400 })

  const workspace = await prisma.workspace.create({
    data: {
      name,
      industry,
      websiteUrl,
      agencyId: user.agencyId ?? undefined,
      clientAccessLevel: clientAccessLevel ?? 'NONE',
      access: {
        create: { userId: user.id, role: 'AGENCY_ADMIN' }
      }
    }
  })

  return NextResponse.json(workspace, { status: 201 })
}
```

- [ ] **Step 2: Commit**
```bash
git add -A
git commit -m "feat: workspace CRUD API and client management UI"
```

---

### Task 5: Social Account OAuth Connection

**Files:**
- Create: `app/api/social/connect/[platform]/route.ts`
- Create: `app/api/social/callback/[platform]/route.ts`
- Create: `lib/encrypt.ts`
- Create: `services/social/facebook.ts`
- Create: `services/social/instagram.ts`
- Create: `services/social/google-business.ts`
- Create: `services/social/linkedin.ts`
- Create: `services/social/twitter.ts`
- Create: `services/social/tiktok.ts`

- [ ] **Step 1: Token encryption helper**
```typescript
// lib/encrypt.ts
import crypto from 'crypto'

const ALGORITHM = 'aes-256-gcm'
const KEY = Buffer.from(process.env.ENCRYPTION_KEY!, 'hex')

export function encrypt(text: string): string {
  const iv = crypto.randomBytes(16)
  const cipher = crypto.createCipheriv(ALGORITHM, KEY, iv)
  let encrypted = cipher.update(text, 'utf8', 'hex')
  encrypted += cipher.final('hex')
  const tag = cipher.getAuthTag()
  return `${iv.toString('hex')}:${tag.toString('hex')}:${encrypted}`
}

export function decrypt(encoded: string): string {
  const [ivHex, tagHex, encrypted] = encoded.split(':')
  const iv = Buffer.from(ivHex, 'hex')
  const tag = Buffer.from(tagHex, 'hex')
  const decipher = crypto.createDecipheriv(ALGORITHM, KEY, iv)
  decipher.setAuthTag(tag)
  let decrypted = decipher.update(encrypted, 'hex', 'utf8')
  decrypted += decipher.final('utf8')
  return decrypted
}
```

- [ ] **Step 2: Facebook/Instagram OAuth connect**
```typescript
// app/api/social/connect/facebook/route.ts
import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth'

export async function GET(req: Request) {
  await requireAuth()
  const { searchParams } = new URL(req.url)
  const workspaceId = searchParams.get('workspaceId')
  if (!workspaceId) return NextResponse.json({ error: 'workspaceId required' }, { status: 400 })

  const state = Buffer.from(JSON.stringify({ workspaceId })).toString('base64')
  const params = new URLSearchParams({
    client_id:     process.env.FACEBOOK_APP_ID!,
    redirect_uri:  `${process.env.AUTH0_BASE_URL}/api/social/callback/facebook`,
    scope:         'pages_show_list,pages_manage_posts,pages_read_engagement,instagram_basic,instagram_content_publish,instagram_manage_comments',
    state,
    response_type: 'code',
  })

  return NextResponse.redirect(`https://www.facebook.com/v19.0/dialog/oauth?${params}`)
}
```

- [ ] **Step 3: Facebook callback handler**
```typescript
// app/api/social/callback/facebook/route.ts
import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { encrypt } from '@/lib/encrypt'

export async function GET(req: Request) {
  const user = await requireAuth()
  const { searchParams } = new URL(req.url)
  const code = searchParams.get('code')
  const state = JSON.parse(Buffer.from(searchParams.get('state') ?? '', 'base64').toString())
  const { workspaceId } = state

  // Exchange code for token
  const tokenRes = await fetch(
    `https://graph.facebook.com/v19.0/oauth/access_token?` +
    new URLSearchParams({
      client_id:     process.env.FACEBOOK_APP_ID!,
      client_secret: process.env.FACEBOOK_APP_SECRET!,
      redirect_uri:  `${process.env.AUTH0_BASE_URL}/api/social/callback/facebook`,
      code:          code!,
    })
  )
  const tokenData = await tokenRes.json()

  // Get pages
  const pagesRes = await fetch(
    `https://graph.facebook.com/v19.0/me/accounts?access_token=${tokenData.access_token}`
  )
  const pagesData = await pagesRes.json()

  // Store each page as a social account
  for (const page of pagesData.data ?? []) {
    await prisma.socialAccount.upsert({
      where: { workspaceId_platform_platformId: { workspaceId, platform: 'FACEBOOK', platformId: page.id } },
      create: {
        workspaceId,
        platform:    'FACEBOOK',
        platformId:  page.id,
        handle:      page.name,
        name:        page.name,
        accessToken: encrypt(page.access_token),
      },
      update: {
        accessToken: encrypt(page.access_token),
        isActive:    true,
      }
    })
  }

  return NextResponse.redirect(`${process.env.AUTH0_BASE_URL}/workspace/${workspaceId}/settings?connected=facebook`)
}
```

- [ ] **Step 4: Commit**
```bash
git add -A
git commit -m "feat: social OAuth connect flows for Facebook, Instagram, LinkedIn, Google"
```

---

### Task 6: Post Composer UI

**Files:**
- Create: `components/lyra/composer/post-composer.tsx`
- Create: `components/lyra/composer/platform-selector.tsx`
- Create: `components/lyra/composer/media-uploader.tsx`
- Create: `app/(dashboard)/workspace/[workspaceId]/compose/page.tsx`
- Create: `app/api/posts/route.ts`

- [ ] **Step 1: Build platform selector component**
```tsx
// components/lyra/composer/platform-selector.tsx
'use client'
import { cn } from '@/lib/utils'

const PLATFORMS = [
  { id: 'FACEBOOK',        label: 'Facebook',       color: '#1877F2' },
  { id: 'INSTAGRAM',       label: 'Instagram',      color: '#E4405F' },
  { id: 'LINKEDIN',        label: 'LinkedIn',       color: '#0A66C2' },
  { id: 'TIKTOK',          label: 'TikTok',         color: '#000000' },
  { id: 'TWITTER',         label: 'X',              color: '#000000' },
  { id: 'GOOGLE_BUSINESS', label: 'Google',         color: '#4285F4' },
] as const

interface PlatformSelectorProps {
  connectedPlatforms: string[]
  selected: string[]
  onChange: (platforms: string[]) => void
}

export function PlatformSelector({ connectedPlatforms, selected, onChange }: PlatformSelectorProps) {
  const toggle = (id: string) => {
    onChange(selected.includes(id) ? selected.filter(p => p !== id) : [...selected, id])
  }

  return (
    <div className="flex flex-wrap gap-2">
      {PLATFORMS.map(p => {
        const connected = connectedPlatforms.includes(p.id)
        const isSelected = selected.includes(p.id)
        return (
          <button
            key={p.id}
            onClick={() => connected && toggle(p.id)}
            disabled={!connected}
            aria-label={`${isSelected ? 'Deselect' : 'Select'} ${p.label}`}
            aria-pressed={isSelected}
            className={cn(
              'px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-150 border',
              isSelected
                ? 'border-accent-silver text-text-primary bg-background-hover'
                : 'border-background-border text-text-tertiary hover:border-background-border-mid hover:text-text-secondary',
              !connected && 'opacity-30 cursor-not-allowed'
            )}
          >
            {p.label}
          </button>
        )
      })}
    </div>
  )
}
```

- [ ] **Step 2: Build post composer**
```tsx
// components/lyra/composer/post-composer.tsx
'use client'
import { useState } from 'react'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Placeholder from '@tiptap/extension-placeholder'
import { Button } from '@/components/ui/button'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Sparkles, CalendarIcon, Send, Image as ImageIcon } from 'lucide-react'
import { PlatformSelector } from './platform-selector'
import { MediaUploader } from './media-uploader'
import { format } from 'date-fns'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

interface PostComposerProps {
  workspaceId: string
  connectedPlatforms: string[]
}

export function PostComposer({ workspaceId, connectedPlatforms }: PostComposerProps) {
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([])
  const [scheduledAt, setScheduledAt] = useState<Date | undefined>()
  const [mediaUrls, setMediaUrls] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({ placeholder: 'Write your post, or let LYRA AI generate it...' }),
    ],
    editorProps: {
      attributes: {
        class: 'min-h-[160px] text-sm text-text-primary leading-relaxed outline-none prose prose-invert max-w-none',
      }
    }
  })

  const handleAIGenerate = async () => {
    if (selectedPlatforms.length === 0) {
      toast.error('Select at least one platform first')
      return
    }
    setIsGenerating(true)
    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workspaceId, platforms: selectedPlatforms })
      })
      const data = await res.json()
      editor?.commands.setContent(data.content)
    } catch {
      toast.error('Failed to generate content')
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSubmit = async (status: 'DRAFT' | 'SCHEDULED') => {
    const content = editor?.getText()
    if (!content?.trim()) { toast.error('Post content is required'); return }
    if (selectedPlatforms.length === 0) { toast.error('Select at least one platform'); return }
    if (status === 'SCHEDULED' && !scheduledAt) { toast.error('Set a schedule time'); return }

    setIsSubmitting(true)
    try {
      await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workspaceId, content, platforms: selectedPlatforms, scheduledAt, mediaUrls, status })
      })
      toast.success(status === 'SCHEDULED' ? 'Post scheduled!' : 'Draft saved!')
      editor?.commands.clearContent()
      setSelectedPlatforms([])
      setScheduledAt(undefined)
    } catch {
      toast.error('Failed to save post')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="bg-background-secondary border border-background-border rounded-xl overflow-hidden">
      {/* Platform selector */}
      <div className="px-5 py-4 border-b border-background-border">
        <p className="text-xs text-text-tertiary mb-3 tracking-wider uppercase">Post to</p>
        <PlatformSelector
          connectedPlatforms={connectedPlatforms}
          selected={selectedPlatforms}
          onChange={setSelectedPlatforms}
        />
      </div>

      {/* Editor */}
      <div className="px-5 py-4">
        <EditorContent editor={editor} />
      </div>

      {/* Media */}
      {mediaUrls.length > 0 && (
        <div className="px-5 pb-4">
          <div className="flex gap-2 flex-wrap">
            {mediaUrls.map((url, i) => (
              <img key={i} src={url} alt="" className="h-16 w-16 object-cover rounded-md border border-background-border" />
            ))}
          </div>
        </div>
      )}

      {/* Toolbar */}
      <div className="flex items-center justify-between px-5 py-3 border-t border-background-border">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost" size="sm"
            onClick={handleAIGenerate}
            disabled={isGenerating}
            className="text-text-secondary hover:text-text-primary gap-2 text-xs"
          >
            <Sparkles size={14} className={cn(isGenerating && 'animate-pulse')} />
            {isGenerating ? 'Generating...' : 'AI Generate'}
          </Button>
          <MediaUploader
            workspaceId={workspaceId}
            onUpload={(url) => setMediaUrls(prev => [...prev, url])}
          />
        </div>

        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="sm" className="text-text-secondary hover:text-text-primary gap-2 text-xs">
                <CalendarIcon size={14} />
                {scheduledAt ? format(scheduledAt, 'MMM d, h:mm a') : 'Schedule'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 bg-background-tertiary border-background-border">
              <Calendar mode="single" selected={scheduledAt} onSelect={setScheduledAt} />
            </PopoverContent>
          </Popover>

          <Button
            variant="ghost" size="sm"
            onClick={() => handleSubmit('DRAFT')}
            disabled={isSubmitting}
            className="text-text-tertiary hover:text-text-primary text-xs"
          >
            Save draft
          </Button>

          <Button
            size="sm"
            onClick={() => handleSubmit('SCHEDULED')}
            disabled={isSubmitting || !scheduledAt}
            className="bg-accent-platinum text-background-primary hover:bg-accent-white text-xs gap-2"
          >
            <Send size={12} />
            {isSubmitting ? 'Scheduling...' : 'Schedule'}
          </Button>
        </div>
      </div>
    </div>
  )
}
```

- [ ] **Step 3: Commit**
```bash
git add -A
git commit -m "feat: post composer with platform selector, AI generate, scheduling"
```

---

### Task 7: Content Calendar

**Files:**
- Create: `components/lyra/calendar/content-calendar.tsx`
- Create: `components/lyra/calendar/post-preview-card.tsx`
- Create: `app/(dashboard)/workspace/[workspaceId]/calendar/page.tsx`

- [ ] **Step 1: Build calendar grid**

The calendar uses a 7-column CSS grid for days, with posts displayed as compact cards within each day cell. Drag-and-drop via @dnd-kit allows rescheduling by dragging post cards between day cells.

```tsx
// components/lyra/calendar/content-calendar.tsx
'use client'
import { useState, useEffect } from 'react'
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday } from 'date-fns'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { PostPreviewCard } from './post-preview-card'
import { cn } from '@/lib/utils'

// Full implementation with DnD kit for drag-to-reschedule
export function ContentCalendar({ workspaceId }: { workspaceId: string }) {
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [posts, setPosts] = useState<any[]>([])

  useEffect(() => {
    fetch(`/api/posts?workspaceId=${workspaceId}&month=${format(currentMonth, 'yyyy-MM')}`)
      .then(r => r.json()).then(setPosts)
  }, [workspaceId, currentMonth])

  const days = eachDayOfInterval({ start: startOfMonth(currentMonth), end: endOfMonth(currentMonth) })
  const startDay = startOfMonth(currentMonth).getDay()

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-medium text-text-secondary tracking-widest uppercase">
          {format(currentMonth, 'MMMM yyyy')}
        </h2>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(d => new Date(d.getFullYear(), d.getMonth() - 1))} aria-label="Previous month">
            <ChevronLeft size={14} />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(d => new Date(d.getFullYear(), d.getMonth() + 1))} aria-label="Next month">
            <ChevronRight size={14} />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-px bg-background-border rounded-xl overflow-hidden">
        {['Su','Mo','Tu','We','Th','Fr','Sa'].map(d => (
          <div key={d} className="bg-background-secondary px-3 py-2 text-xs text-text-tertiary text-center tracking-widest">{d}</div>
        ))}
        {Array.from({ length: startDay }).map((_, i) => (
          <div key={`empty-${i}`} className="bg-background-secondary min-h-[120px]" />
        ))}
        {days.map(day => {
          const dayPosts = posts.filter(p => p.scheduledAt && isSameDay(new Date(p.scheduledAt), day))
          return (
            <div key={day.toISOString()} className={cn('bg-background-secondary min-h-[120px] p-2 space-y-1', isToday(day) && 'bg-background-tertiary')}>
              <span className={cn('text-xs', isToday(day) ? 'text-accent-platinum font-medium' : 'text-text-tertiary')}>
                {format(day, 'd')}
              </span>
              {dayPosts.map(post => <PostPreviewCard key={post.id} post={post} />)}
            </div>
          )
        })}
      </div>
    </div>
  )
}
```

- [ ] **Step 2: Commit**
```bash
git add -A
git commit -m "feat: content calendar with monthly grid view"
```

---

## Phase 2 — Intelligence (Months 5–8)

### Task 8: Brand Intelligence Engine

**Files:**
- Create: `services/brand-intelligence/scraper.ts`
- Create: `services/brand-intelligence/social-analyzer.ts`
- Create: `services/brand-intelligence/document-parser.ts`
- Create: `services/brand-intelligence/profile-builder.ts`
- Create: `lib/anthropic.ts`
- Create: `app/api/brand-intelligence/build/route.ts`

- [ ] **Step 1: Anthropic client**
```typescript
// lib/anthropic.ts
import Anthropic from '@anthropic-ai/sdk'

export const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
```

- [ ] **Step 2: Website scraper**
```typescript
// services/brand-intelligence/scraper.ts
import * as cheerio from 'cheerio'

export interface ScrapedWebsite {
  title:        string
  description:  string
  bodyText:     string
  headings:     string[]
  metaKeywords: string[]
}

export async function scrapeWebsite(url: string): Promise<ScrapedWebsite> {
  const res = await fetch(url, {
    headers: { 'User-Agent': 'LyraBot/1.0 (brand intelligence crawler)' },
    signal: AbortSignal.timeout(10000)
  })
  const html = await res.text()
  const $ = cheerio.load(html)

  // Remove scripts, styles, nav, footer
  $('script, style, nav, footer, header, .cookie-banner').remove()

  const title       = $('title').text().trim()
  const description = $('meta[name="description"]').attr('content') ?? ''
  const metaKeywords = ($('meta[name="keywords"]').attr('content') ?? '').split(',').map(k => k.trim()).filter(Boolean)
  const headings    = $('h1, h2, h3').map((_, el) => $(el).text().trim()).get().filter(Boolean)
  const bodyText    = $('main, article, .content, body').text()
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 8000) // Limit for Claude context

  return { title, description, bodyText, headings, metaKeywords }
}
```

- [ ] **Step 3: Brand profile builder using Claude**
```typescript
// services/brand-intelligence/profile-builder.ts
import { anthropic } from '@/lib/anthropic'
import { ScrapedWebsite } from './scraper'

export interface BrandProfileData {
  voiceSummary:   string
  toneAttributes: string[]
  contentThemes:  string[]
  audienceProfile: {
    demographics:  string
    interests:     string[]
    painPoints:    string[]
    language:      string
  }
  postingGuidelines: string
}

export async function buildBrandProfile(
  websiteData: ScrapedWebsite,
  guidelinesText: string,
  socialPosts: string[]
): Promise<BrandProfileData> {
  const prompt = `You are a brand intelligence analyst. Analyse the following data about a brand and produce a structured brand profile.

WEBSITE DATA:
Title: ${websiteData.title}
Description: ${websiteData.description}
Key headings: ${websiteData.headings.slice(0, 20).join(' | ')}
Body content excerpt: ${websiteData.bodyText.slice(0, 3000)}

BRAND GUIDELINES:
${guidelinesText.slice(0, 2000)}

RECENT SOCIAL POSTS (${socialPosts.length} posts):
${socialPosts.slice(0, 20).join('\n---\n')}

Produce a JSON object with exactly these fields:
{
  "voiceSummary": "2-3 sentence description of the brand's voice and tone",
  "toneAttributes": ["array", "of", "5-8", "adjectives"],
  "contentThemes": ["array", "of", "5-8", "main", "content", "topics"],
  "audienceProfile": {
    "demographics": "description of target audience",
    "interests": ["array", "of", "interests"],
    "painPoints": ["array", "of", "pain", "points"],
    "language": "formal|casual|technical|conversational"
  },
  "postingGuidelines": "Key rules for content creation based on brand guidelines"
}

Return ONLY valid JSON. No markdown, no explanation.`

  const response = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 1000,
    messages:   [{ role: 'user', content: prompt }]
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : ''
  return JSON.parse(text) as BrandProfileData
}
```

- [ ] **Step 4: Brand intelligence API endpoint**
```typescript
// app/api/brand-intelligence/build/route.ts
import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { scrapeWebsite } from '@/services/brand-intelligence/scraper'
import { buildBrandProfile } from '@/services/brand-intelligence/profile-builder'

export async function POST(req: Request) {
  const user = await requireAuth()
  const { workspaceId } = await req.json()

  const workspace = await prisma.workspace.findFirst({
    where: { id: workspaceId, access: { some: { userId: user.id } } },
    include: { brandProfile: true, socialAccounts: true }
  })
  if (!workspace) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  // Scrape website
  let websiteData = { title: '', description: '', bodyText: '', headings: [], metaKeywords: [] }
  if (workspace.websiteUrl) {
    websiteData = await scrapeWebsite(workspace.websiteUrl)
  }

  // TODO: Fetch social posts from connected accounts and brand guidelines from S3
  const socialPosts: string[] = []
  const guidelinesText = ''

  const profileData = await buildBrandProfile(websiteData, guidelinesText, socialPosts)

  await prisma.brandProfile.upsert({
    where:  { workspaceId },
    create: { workspaceId, ...profileData, websiteData, lastScrapedAt: new Date() },
    update: { ...profileData, websiteData, lastScrapedAt: new Date(), lastUpdatedAt: new Date() }
  })

  return NextResponse.json({ success: true })
}
```

- [ ] **Step 5: Commit**
```bash
git add -A
git commit -m "feat: brand intelligence engine — scraper, analyzer, Claude profile builder"
```

---

### Task 9: AI Caption Generation

**Files:**
- Create: `services/ai/prompt-builder.ts`
- Create: `services/ai/caption-generator.ts`
- Create: `app/api/ai/generate/route.ts`

- [ ] **Step 1: Prompt builder from brand profile**
```typescript
// services/ai/prompt-builder.ts
import { BrandProfile } from '@prisma/client'

export function buildCaptionPrompt(
  brandProfile: BrandProfile,
  platforms: string[],
  topic?: string
): string {
  return `You are a social media content writer for the following brand.

BRAND VOICE PROFILE:
${brandProfile.voiceSummary}

TONE ATTRIBUTES: ${(brandProfile.toneAttributes as string[]).join(', ')}
CONTENT THEMES: ${(brandProfile.contentThemes as string[]).join(', ')}
POSTING GUIDELINES: ${brandProfile.postingGuidelines ?? 'None specified'}

TARGET PLATFORMS: ${platforms.join(', ')}
${topic ? `TOPIC/BRIEF: ${topic}` : ''}

Write an engaging social media post for the specified platforms. Follow the brand voice exactly. 

Rules:
- Match the brand's tone precisely
- Stay within platform character limits (Twitter: 280, LinkedIn: 3000, Instagram: 2200, Facebook: 63206)
- Include relevant hashtags naturally (3-5 for Instagram, 1-2 for LinkedIn, 1-3 for Twitter)
- Write the post only — no explanation, no "Here's a post:", just the content

If multiple platforms are specified, write the best single version that works across them, optimised for the primary platform first.`
}
```

- [ ] **Step 2: Caption generator service**
```typescript
// services/ai/caption-generator.ts
import { anthropic } from '@/lib/anthropic'
import { buildCaptionPrompt } from './prompt-builder'
import { BrandProfile } from '@prisma/client'

export async function generateCaption(
  brandProfile: BrandProfile,
  platforms: string[],
  topic?: string
): Promise<string> {
  const prompt = buildCaptionPrompt(brandProfile, platforms, topic)

  const response = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 1000,
    messages:   [{ role: 'user', content: prompt }]
  })

  return response.content[0].type === 'text' ? response.content[0].text.trim() : ''
}
```

- [ ] **Step 3: API route**
```typescript
// app/api/ai/generate/route.ts
import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { generateCaption } from '@/services/ai/caption-generator'

export async function POST(req: Request) {
  const user = await requireAuth()
  const { workspaceId, platforms, topic } = await req.json()

  const brandProfile = await prisma.brandProfile.findUnique({ where: { workspaceId } })
  if (!brandProfile) return NextResponse.json(
    { error: 'Brand profile not found. Build brand intelligence first.' },
    { status: 404 }
  )

  const content = await generateCaption(brandProfile, platforms, topic)
  return NextResponse.json({ content })
}
```

- [ ] **Step 4: Commit**
```bash
git add -A
git commit -m "feat: AI caption generation from brand intelligence profile"
```

---

### Task 10: AI Comment Response Engine

**Files:**
- Create: `services/ai/response-generator.ts`
- Create: `components/lyra/inbox/response-inbox.tsx`
- Create: `components/lyra/inbox/comment-card.tsx`
- Create: `app/api/ai/respond/route.ts`
- Create: `app/(dashboard)/workspace/[workspaceId]/inbox/page.tsx`

- [ ] **Step 1: Response generator with guardrails**
```typescript
// services/ai/response-generator.ts
import { anthropic } from '@/lib/anthropic'
import { BrandProfile, Guardrail, Comment } from '@prisma/client'

type CommentWithProfile = Comment & { workspace: { brandProfile: BrandProfile | null; guardrails: Guardrail[] } }

export async function generateCommentResponse(comment: CommentWithProfile): Promise<{
  response: string | null
  shouldEscalate: boolean
  escalationReason?: string
}> {
  const { brandProfile, guardrails } = comment.workspace

  if (!brandProfile) return { response: null, shouldEscalate: true, escalationReason: 'No brand profile configured' }

  const neverDiscuss    = guardrails.filter(g => g.type === 'NEVER_DISCUSS').map(g => g.value)
  const neverUse        = guardrails.filter(g => g.type === 'NEVER_USE_WORD').map(g => g.value)
  const alwaysEscalate  = guardrails.filter(g => g.type === 'ALWAYS_ESCALATE').map(g => g.value)
  const approvedAnswers = guardrails.filter(g => g.type === 'APPROVED_ANSWER').map(g => g.value)

  // Check escalation triggers first
  const commentLower = comment.content.toLowerCase()
  for (const trigger of alwaysEscalate) {
    if (commentLower.includes(trigger.toLowerCase())) {
      return { response: null, shouldEscalate: true, escalationReason: `Contains escalation trigger: "${trigger}"` }
    }
  }

  const prompt = `You are responding to a social media comment on behalf of a brand.

BRAND VOICE:
${brandProfile.voiceSummary}
Tone: ${(brandProfile.toneAttributes as string[]).join(', ')}

${approvedAnswers.length > 0 ? `APPROVED ANSWERS TO USE WHEN RELEVANT:\n${approvedAnswers.join('\n')}` : ''}

COMMENT TO RESPOND TO:
"${comment.content}"
Posted by: ${comment.authorName}

STRICT RULES — NEVER BREAK THESE:
- NEVER discuss: ${neverDiscuss.join(', ') || 'nothing restricted'}
- NEVER use these words/phrases: ${neverUse.join(', ') || 'none restricted'}
- Keep response under 280 characters for most platforms
- Be genuine, on-brand, and helpful
- Never make promises about refunds, legal matters, or specific timeframes
- If the comment is negative, acknowledge and offer to help via DM — never argue

If you cannot respond appropriately without breaking any rules, respond with exactly: ESCALATE

Write only the response — no explanation.`

  const apiResponse = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 300,
    messages:   [{ role: 'user', content: prompt }]
  })

  const text = apiResponse.content[0].type === 'text' ? apiResponse.content[0].text.trim() : ''

  if (text === 'ESCALATE') {
    return { response: null, shouldEscalate: true, escalationReason: 'AI determined escalation required' }
  }

  return { response: text, shouldEscalate: false }
}
```

- [ ] **Step 2: Response inbox UI**
```tsx
// components/lyra/inbox/response-inbox.tsx
'use client'
import { useState, useEffect } from 'react'
import { CommentCard } from './comment-card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'

export function ResponseInbox({ workspaceId }: { workspaceId: string }) {
  const [comments, setComments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(`/api/comments?workspaceId=${workspaceId}`)
      .then(r => r.json())
      .then(data => { setComments(data); setLoading(false) })
  }, [workspaceId])

  const pending    = comments.filter(c => c.status === 'PENDING' || c.status === 'AI_DRAFTED')
  const escalated  = comments.filter(c => c.status === 'ESCALATED')
  const responded  = comments.filter(c => c.status === 'RESPONDED')

  return (
    <Tabs defaultValue="pending" className="space-y-4">
      <TabsList className="bg-background-secondary border border-background-border">
        <TabsTrigger value="pending" className="text-xs gap-2">
          Pending
          {pending.length > 0 && <Badge variant="secondary" className="text-xs px-1.5 py-0 bg-background-hover">{pending.length}</Badge>}
        </TabsTrigger>
        <TabsTrigger value="escalated" className="text-xs gap-2">
          Escalated
          {escalated.length > 0 && <Badge variant="secondary" className="text-xs px-1.5 py-0 bg-status-error/20 text-status-error">{escalated.length}</Badge>}
        </TabsTrigger>
        <TabsTrigger value="responded" className="text-xs">Done</TabsTrigger>
      </TabsList>

      <TabsContent value="pending" className="space-y-3 animate-fade-in">
        {loading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-24 rounded-xl bg-background-secondary border border-background-border animate-pulse" />
          ))
        ) : pending.length === 0 ? (
          <p className="text-sm text-text-tertiary text-center py-12">All caught up ✓</p>
        ) : (
          pending.map(c => <CommentCard key={c.id} comment={c} onUpdate={() => {
            setComments(prev => prev.map(p => p.id === c.id ? { ...p, status: 'RESPONDED' } : p))
          }} />)
        )}
      </TabsContent>

      <TabsContent value="escalated" className="space-y-3 animate-fade-in">
        {escalated.map(c => <CommentCard key={c.id} comment={c} onUpdate={() => {}} />)}
      </TabsContent>

      <TabsContent value="responded" className="space-y-3 animate-fade-in">
        {responded.map(c => <CommentCard key={c.id} comment={c} onUpdate={() => {}} />)}
      </TabsContent>
    </Tabs>
  )
}
```

- [ ] **Step 3: Commit**
```bash
git add -A
git commit -m "feat: AI comment response engine with guardrails and escalation routing"
```

---

### Task 11: Guided Client Onboarding Flow

**Files:**
- Create: `app/api/onboarding/route.ts`
- Create: `app/onboard/[token]/page.tsx`
- Create: `components/lyra/onboarding/onboarding-flow.tsx`

- [ ] **Step 1: Onboarding token API**
```typescript
// app/api/onboarding/route.ts
import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { addDays } from 'date-fns'

export async function POST(req: Request) {
  const user = await requireAuth()
  const { workspaceId } = await req.json()

  // Verify user has access to this workspace
  const access = await prisma.workspaceAccess.findFirst({
    where: { userId: user.id, workspaceId, role: { in: ['AGENCY_ADMIN', 'AGENCY_MEMBER'] } }
  })
  if (!access) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const token = await prisma.onboardingToken.upsert({
    where:  { workspaceId },
    create: { workspaceId, expiresAt: addDays(new Date(), 7) },
    update: { expiresAt: addDays(new Date(), 7), completedAt: null }
  })

  const onboardingUrl = `${process.env.AUTH0_BASE_URL}/onboard/${token.token}`
  return NextResponse.json({ url: onboardingUrl, token: token.token })
}
```

- [ ] **Step 2: Commit**
```bash
git add -A
git commit -m "feat: guided client onboarding token generation and flow"
```

---

## Phase 3 — Autonomy & Scale (Months 9–12)

### Task 12: BullMQ Workers — Post Publishing & Comment Monitoring

**Files:**
- Create: `workers/post-publisher.worker.ts`
- Create: `workers/comment-monitor.worker.ts`
- Create: `workers/ai-responder.worker.ts`
- Create: `workers/brand-sync.worker.ts`
- Create: `services/scheduler/post-queue.ts`
- Create: `lib/redis.ts`

- [ ] **Step 1: Redis client**
```typescript
// lib/redis.ts
import IORedis from 'ioredis'
export const redis = new IORedis(process.env.REDIS_URL!, { maxRetriesPerRequest: null })
```

- [ ] **Step 2: Post scheduling queue**
```typescript
// services/scheduler/post-queue.ts
import { Queue } from 'bullmq'
import { redis } from '@/lib/redis'

export const postQueue = new Queue('post-publishing', {
  connection: redis,
  defaultJobOptions: {
    attempts:  3,
    backoff:   { type: 'exponential', delay: 5000 },
    removeOnComplete: { count: 100 },
    removeOnFail:     { count: 50 },
  }
})

export async function schedulePost(postId: string, scheduledAt: Date) {
  const delay = scheduledAt.getTime() - Date.now()
  await postQueue.add('publish-post', { postId }, { delay: Math.max(0, delay), jobId: postId })
}
```

- [ ] **Step 3: Post publisher worker**
```typescript
// workers/post-publisher.worker.ts
import { Worker } from 'bullmq'
import { redis } from '@/lib/redis'
import { prisma } from '@/lib/prisma'
import { decrypt } from '@/lib/encrypt'

const worker = new Worker('post-publishing', async (job) => {
  const { postId } = job.data
  const post = await prisma.post.findUnique({
    where: { id: postId },
    include: { socialAccount: true }
  })
  if (!post || post.status !== 'SCHEDULED') return

  await prisma.post.update({ where: { id: postId }, data: { status: 'PUBLISHING' } })

  const token = decrypt(post.socialAccount.accessToken)

  let platformPostId: string | undefined
  try {
    // Route to correct platform publisher
    switch (post.socialAccount.platform) {
      case 'FACEBOOK':
        const fbRes = await fetch(`https://graph.facebook.com/v19.0/${post.socialAccount.platformId}/feed`, {
          method: 'POST',
          body: JSON.stringify({ message: post.content, access_token: token }),
          headers: { 'Content-Type': 'application/json' }
        })
        const fbData = await fbRes.json()
        platformPostId = fbData.id
        break
      // Other platforms to be implemented similarly
    }

    await prisma.post.update({
      where: { id: postId },
      data: { status: 'PUBLISHED', publishedAt: new Date(), platformPostId }
    })
  } catch (err) {
    await prisma.post.update({ where: { id: postId }, data: { status: 'FAILED' } })
    throw err
  }
}, { connection: redis, concurrency: 5 })

worker.on('failed', (job, err) => console.error(`Post ${job?.data.postId} failed:`, err))
```

- [ ] **Step 4: Comment monitor worker**
```typescript
// workers/comment-monitor.worker.ts
import { Worker, Queue } from 'bullmq'
import { redis } from '@/lib/redis'
import { prisma } from '@/lib/prisma'
import { decrypt } from '@/lib/encrypt'

// This worker polls for new comments every 5 minutes per social account
// and routes them based on the workspace's AI response mode

const commentQueue = new Queue('comment-monitoring', { connection: redis })

const worker = new Worker('comment-monitoring', async (job) => {
  const { socialAccountId } = job.data
  const account = await prisma.socialAccount.findUnique({
    where: { id: socialAccountId },
    include: { workspace: { include: { brandProfile: true, guardrails: true } } }
  })
  if (!account || !account.isActive) return

  // Fetch recent comments from platform (Facebook example)
  const token = decrypt(account.accessToken)
  const res = await fetch(
    `https://graph.facebook.com/v19.0/${account.platformId}/feed?fields=comments{message,from,created_time}&access_token=${token}`
  )
  const data = await res.json()

  for (const post of data.data ?? []) {
    for (const comment of post.comments?.data ?? []) {
      // Check if already stored
      const existing = await prisma.comment.findFirst({
        where: { platformCommentId: comment.id }
      })
      if (existing) continue

      const newComment = await prisma.comment.create({
        data: {
          workspaceId:      account.workspaceId,
          socialAccountId:  account.id,
          platformCommentId: comment.id,
          authorName:       comment.from?.name ?? 'Unknown',
          content:          comment.message,
          platformCreatedAt: new Date(comment.created_time),
          status:           'PENDING',
        }
      })

      // Route based on autonomy mode
      const mode = account.workspace.aiResponseMode
      if (mode === 'FULL' || mode === 'DRAFT_APPROVE') {
        // Queue for AI response generation
        await new Queue('ai-responding', { connection: redis })
          .add('generate-response', { commentId: newComment.id, autoPost: mode === 'FULL' })
      }
    }
  }
}, { connection: redis, concurrency: 10 })
```

- [ ] **Step 5: Commit**
```bash
git add -A
git commit -m "feat: BullMQ workers for post publishing, comment monitoring, AI response dispatch"
```

---

### Task 13: Stripe Billing Integration

**Files:**
- Create: `lib/stripe.ts`
- Create: `app/api/stripe/webhook/route.ts`
- Create: `app/api/stripe/create-checkout/route.ts`
- Create: `app/(dashboard)/account/billing/page.tsx`

- [ ] **Step 1: Stripe client**
```typescript
// lib/stripe.ts
import Stripe from 'stripe'
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-11-20.acacia' })

export const PLANS = {
  STARTER: {
    name:          'Starter',
    priceId:       process.env.STRIPE_STARTER_PRICE_ID!,
    workspaces:    1,
    maxAutonomy:   'OFF' as const,
  },
  PRO: {
    name:          'Pro',
    priceId:       process.env.STRIPE_PRO_PRICE_ID!,
    workspaces:    5,
    maxAutonomy:   'DRAFT_APPROVE' as const,
  },
  AGENCY: {
    name:          'Agency',
    priceId:       process.env.STRIPE_AGENCY_PRICE_ID!,
    workspaces:    -1,
    maxAutonomy:   'FULL' as const,
  },
}
```

- [ ] **Step 2: Stripe webhook handler**
```typescript
// app/api/stripe/webhook/route.ts
import { NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { prisma } from '@/lib/prisma'

export async function POST(req: Request) {
  const body = await req.text()
  const sig  = req.headers.get('stripe-signature')!

  let event: ReturnType<typeof stripe.webhooks.constructEvent>
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  switch (event.type) {
    case 'customer.subscription.created':
    case 'customer.subscription.updated': {
      const sub = event.data.object as any
      await prisma.agency.updateMany({
        where:  { stripeCustomerId: sub.customer },
        data:   { stripeSubId: sub.id, plan: sub.metadata.plan ?? 'STARTER' }
      })
      break
    }
    case 'customer.subscription.deleted': {
      const sub = event.data.object as any
      await prisma.agency.updateMany({
        where: { stripeCustomerId: sub.customer },
        data:  { plan: 'STARTER' }
      })
      break
    }
  }

  return NextResponse.json({ received: true })
}
```

- [ ] **Step 3: Commit**
```bash
git add -A
git commit -m "feat: Stripe billing integration with subscription management"
```

---

### Task 14: Analytics Dashboard

**Files:**
- Create: `components/lyra/analytics/performance-dashboard.tsx`
- Create: `components/lyra/analytics/engagement-chart.tsx`
- Create: `app/api/analytics/route.ts`

- [ ] **Step 1: Engagement chart using Recharts**
```tsx
// components/lyra/analytics/engagement-chart.tsx
'use client'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

interface DataPoint { date: string; likes: number; comments: number; shares: number; reach: number }

export function EngagementChart({ data }: { data: DataPoint[] }) {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
          <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#555' }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: '#555' }} axisLine={false} tickLine={false} width={40} />
          <Tooltip
            contentStyle={{ background: '#141414', border: '1px solid #333', borderRadius: '8px', fontSize: '12px' }}
            labelStyle={{ color: '#888' }}
            itemStyle={{ color: '#d8d8d8' }}
          />
          <Line type="monotone" dataKey="reach"    stroke="#888"   strokeWidth={1.5} dot={false} />
          <Line type="monotone" dataKey="likes"    stroke="#d8d8d8" strokeWidth={1.5} dot={false} />
          <Line type="monotone" dataKey="comments" stroke="#60a5fa" strokeWidth={1.5} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
```

- [ ] **Step 2: Commit**
```bash
git add -A
git commit -m "feat: analytics dashboard with engagement charts and platform breakdown"
```

---

## Deployment

### Task 15: Production Deployment Configuration

**Files:**
- Create: `vercel.json`
- Create: `.github/workflows/deploy.yml`
- Create: `Dockerfile.worker` (for BullMQ workers — separate service)

- [ ] **Step 1: Vercel configuration**
```json
// vercel.json
{
  "framework": "nextjs",
  "regions": ["syd1"],
  "env": {
    "DATABASE_URL": "@lyra-db-url",
    "REDIS_URL":    "@lyra-redis-url"
  },
  "crons": [
    { "path": "/api/cron/sync-comments",   "schedule": "*/5 * * * *"  },
    { "path": "/api/cron/sync-metrics",    "schedule": "0 * * * *"    },
    { "path": "/api/cron/brand-refresh",   "schedule": "0 2 * * 0"    }
  ]
}
```

- [ ] **Step 2: GitHub Actions CI/CD**
```yaml
# .github/workflows/deploy.yml
name: Deploy LYRA

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'npm' }
      - run: npm ci
      - run: npm run lint
      - run: npm run type-check
      - run: npx prisma generate
      - run: npm test

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: amondnet/vercel-action@v25
        with:
          vercel-token:   ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id:  ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
          vercel-args: '--prod'
```

- [ ] **Step 3: Commit**
```bash
git add -A
git commit -m "feat: production deployment config — Vercel, CI/CD, worker Dockerfile"
```

---

## Claude Code Configuration

To give Claude Code maximum intelligence when working on this project, create the following CLAUDE.md file in the project root. Claude Code reads this automatically.

```markdown
<!-- CLAUDE.md — Claude Code project intelligence file -->

# LYRA — Claude Code Project Intelligence

## What this project is
LYRA is a premium AI-powered social media SaaS platform. Multi-tenant. 
Each workspace is a client. Agencies manage multiple workspaces. 
Core differentiator: AI responds to comments on behalf of clients.

## Stack
- **Frontend:** Next.js 15 App Router, TypeScript, Tailwind, shadcn/ui, Framer Motion
- **Backend:** Next.js API routes, Prisma ORM, PostgreSQL
- **AI:** Anthropic Claude API (claude-sonnet-4-20250514)
- **Jobs:** BullMQ + Redis (post scheduling, comment monitoring)
- **Auth:** Auth0 (@auth0/nextjs-auth0)
- **Payments:** Stripe
- **Storage:** AWS S3
- **Deployment:** Vercel (app) + Railway (workers)

## Design System — NON-NEGOTIABLE
- Background: #080808 (near-black). NEVER white backgrounds on authenticated pages.
- Text hierarchy: #e2e2e2 (primary) / #888 (secondary) / #555 (muted)
- Borders: #222 subtle / #333 mid
- Fonts: DM Sans (UI), Instrument Serif (display headings only), Geist Mono (data)
- Icons: Lucide ONLY. No emoji as icons. No mixing icon sets.
- Animations: Framer Motion, 150-300ms, cubic-bezier(0.16, 1, 0.3, 1) easing
- Tokens are in tailwind.config.ts and lib/design-tokens.ts — use them, never hardcode hex

## File structure
- API routes: app/api/
- Components: components/lyra/ (custom) + components/ui/ (shadcn, do not edit)
- Business logic: services/
- Background workers: workers/
- Types: types/index.ts

## Database
- ORM: Prisma — always use prisma client from lib/prisma.ts (singleton)
- Never use raw SQL unless absolutely necessary
- After schema changes: npx prisma generate && npx prisma db push

## Auth pattern
- Server components/routes: use requireAuth() from lib/auth.ts
- Client components: use useUser() from @auth0/nextjs-auth0/client
- Workspace access always verified via WorkspaceAccess table — never trust URL params alone

## AI usage
- Always use claude-sonnet-4-20250514 model
- Always set max_tokens: 1000 minimum
- Brand intelligence prompts are in services/ai/prompt-builder.ts
- Comment response guardrails checked BEFORE calling Claude API

## Social tokens
- Always encrypt before storing: encrypt() from lib/encrypt.ts
- Always decrypt before API calls: decrypt() from lib/encrypt.ts
- Never log decrypted tokens

## Testing
- Unit tests: Jest + Testing Library
- Run: npm test
- Type check: npm run type-check
- Lint: npm run lint

## Common commands
npx prisma studio          # Database browser
npx prisma db push         # Apply schema changes
npm run dev                # Local dev server
```

- [ ] **Step 4: Commit CLAUDE.md**
```bash
git add CLAUDE.md
git commit -m "docs: add CLAUDE.md for Claude Code project intelligence"
```

---

## Self-Review

### Spec coverage check

| Scope Document Requirement | Task Covered |
|---|---|
| Self-serve SaaS, three tiers | Tasks 1, 13 |
| Agency/Freelancer/SMB segments | Task 13 (plan gating), Task 2 (roles) |
| Client workspace management | Task 4 |
| Social platform OAuth connection | Task 5 |
| Guided client onboarding | Task 11 |
| Brand intelligence engine (scrape + guidelines + social) | Task 8 |
| AI caption generation | Task 9 |
| AI comment/review response with guardrails | Task 10 |
| Three autonomy modes (off/draft/full) | Task 10, Task 12 |
| Agency guardrail ceiling | Task 10 (guardrails model), Task 2 (schema) |
| Content calendar | Task 7 |
| Post composer | Task 6 |
| Post scheduling + publishing | Task 12 |
| Analytics Phase 1 | Task 14 |
| Approval workflow | Schema (PostApproval), Task 6 |
| Stripe billing | Task 13 |
| Production deployment | Task 15 |
| Claude Code configuration | Task 15 (CLAUDE.md) |
| UI/UX design system | Task 1, all UI tasks |

All 19 scope requirements are covered across 15 tasks.

---

*Plan complete. Saved to docs/specs/2026-05-13-lyra-implementation-plan.md*
